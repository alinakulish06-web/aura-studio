from django.contrib import admin
from .models import Service, News

admin.site.register(Service)
admin.site.register(News)